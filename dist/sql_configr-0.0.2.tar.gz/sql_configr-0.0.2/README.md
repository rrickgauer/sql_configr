# sql_configr

Quickly create a MySQL credentials json file.